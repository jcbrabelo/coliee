import os
import shutil
import json


def do_migrate(dir_path, output_path, golden_labels):
    files = os.listdir(dir_path)
    last_case_int = 0
    if len(golden_labels) > 0:
        last_case_int = int(sorted(golden_labels.keys())[-1])

    for filename in files:
        fullpath = os.path.join(dir_path, filename)
        if os.path.isdir(fullpath):
            print('Migrating {}'.format(fullpath))
            new_folder_name = '{:03d}'.format(int(filename)+last_case_int)
            shutil.copytree(os.path.join(dir_path, filename), os.path.join(output_path, new_folder_name))
        elif filename.endswith('.json'):
            print('Updating golden labels')
            with open(fullpath, 'r') as f:
                current_golden_labels = json.load(f)
                for case_id in current_golden_labels.keys():
                    new_case_id = '{:03d}'.format(int(case_id)+last_case_int)
                    golden_labels[new_case_id] = current_golden_labels[case_id]


def migrate(train_path, test_path, output_path):
    os.makedirs(output_path)

    golden_labels = {}
    do_migrate(train_path, output_path, golden_labels)
    do_migrate(test_path, output_path, golden_labels)
    with open(os.path.join(output_path, 'golden_labels.json'), 'w') as f:
        json.dump(golden_labels, f)


if __name__ == '__main__':
    #migrate_('/Users/jrabelo/Downloads/task1_train', '/Users/jrabelo/Downloads/task1_test', '/Users/jrabelo/Downloads/task1_2019_migration')
    migrate('/Users/jrabelo/Documents/coliee2021/zip_files/task2_2021_train', 
            '/Users/jrabelo/Documents/coliee2021/zip_files/task2_2021_test_nolabels',
            '/Users/jrabelo/Documents/coliee2022/task2_train')