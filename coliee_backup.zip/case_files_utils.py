from bs4 import BeautifulSoup
import os
import shutil
import re

INPUT_DIR = '/Users/jrabelo/Documents/coliee2020/Compass Federal Court Cases/HTML files'


def get_inner_text(html_filepath):
    if os.path.isdir(html_filepath):
        print('Skipping path {} at it is actually a directory, not the HTML file'.format(html_filepath))
        return ''

    with open(html_filepath) as f:
        soup = BeautifulSoup(f, features="html.parser")

    # kill all script and style elements
    for script in soup(["script", "style"]):
        script.extract()  # rip it out

    # get text
    text = soup.get_text()

    # break into lines and remove leading and trailing space on each
    lines = (line.strip() for line in text.splitlines())
    # break multi-headlines into a line each
    chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
    # drop blank lines
    text = '\n'.join(chunk for chunk in chunks if chunk)

    return text


def find_pattern_in_text(pattern, string):
    refs = []
    if pattern is not None:
        occurs = re.finditer(pattern, string)
        for occur in occurs:
            refs.append((occur.start(), occur.end()))

    return refs


def filter_case_id(case_id):
    return case_id.split(':')[0]


def find_case_contents_path(case_id):
    case_id = filter_case_id(case_id)
    for (top, dirnames, filenames) in os.walk(INPUT_DIR):
        if top.endswith(case_id):
            for filename in filenames:
                if filename.lower().count('content') > 0:
                    return os.path.join(top, filename)
            for dirname in dirnames:
                if dirname.lower().count('content') > 0:
                    content_path = os.path.join(top, dirname)
                    files_in_dir = os.listdir(content_path)
                    if len(files_in_dir) == 1:
                        return os.path.join(content_path, files_in_dir[0])
                    else:
                        print('Unexpected number of content files in dir {}'.format(content_path))
    return None